import SignUp from './SignUp'

export default function Home() {
  return (
    <div>
      <SignUp />
    </div>
  )
}
