export default function index() {
    return (
        <div>
            Signup
        </div>
    )
}
